// src/App.jsx
import React, { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, useLocation, useNavigate } from 'react-router-dom';
import { AppProvider } from './context/AppContext';
import { CartProvider } from './context/CartContext';
import useTheme from './hooks/useTheme';

// Pages
import HomePage from './pages/HomePage';
import CatalogPage from './pages/CatalogPage';
import ProductPage from './pages/ProductPage';
import CartPage from './pages/CartPage';
import CheckoutPage from './pages/CheckoutPage';
import OrderStatusPage from './pages/OrderStatusPage';
import OrderSuccessPage from './pages/OrderSuccessPage';

// Global CSS
import './assets/styles/global.css';

const App = () => {
    // Модифицируем стили body для правильного скроллинга
    useEffect(() => {
        document.body.style.overflow = 'hidden';
        document.body.style.position = 'fixed';
        document.body.style.width = '100%';
        document.body.style.height = '100%';
        document.body.style.top = '0';
        document.body.style.left = '0';

        return () => {
            document.body.style.overflow = '';
            document.body.style.position = '';
            document.body.style.width = '';
            document.body.style.height = '';
            document.body.style.top = '';
            document.body.style.left = '';
        };
    }, []);

    return (
        <AppProvider>
            <CartProvider>
                <Router basename="/tma">
                    <AppContent />
                </Router>
            </CartProvider>
        </AppProvider>
    );
};

// Выносим контент в отдельный компонент
const AppContent = () => {
    useTheme();
    const location = useLocation();
    const navigate = useNavigate();

    useEffect(() => {
        // Если мы на странице статуса заказа, но URL начинается с /tma
        if (location.pathname.includes('/tma/order/status/')) {
            // Извлекаем orderId из URL
            const orderId = location.pathname.split('/').pop();

            // Перенаправляем на маршрут без /tma префикса
            navigate(`/order/status/${orderId}`, { replace: true });
        }
    }, [location, navigate]);

    useEffect(() => {
        // Проверяем, был ли пользователь в процессе оплаты
        const paymentPending = localStorage.getItem('paymentPending');
        const orderId = localStorage.getItem('paymentOrderId');

        if (paymentPending === 'true' && orderId && location.pathname === '/checkout') {
            console.log('Обнаружен незавершенный платеж, перенаправление на страницу статуса заказа');

            // Очищаем флаги платежа
            localStorage.removeItem('paymentPending');
            localStorage.removeItem('paymentOrderId');

            // Перенаправляем на страницу статуса заказа
            navigate(`/order/status/${orderId}`, { replace: true });
        }
    }, [location.pathname, navigate]);

    return (
        <div className="app-content">
            <Routes>
                <Route path="/" element={<HomePage />} />
                <Route path="/catalog/:categoryId" element={<CatalogPage />} />
                <Route path="/product/:productId" element={<ProductPage />} />
                <Route path="/cart" element={<CartPage />} />
                <Route path="/checkout" element={<CheckoutPage />} />
                <Route path="/order/status/:orderId" element={<OrderStatusPage />} />
                <Route path="/order/success/:orderId" element={<OrderSuccessPage />} />
                <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
        </div>
    );
};

export default App;
