// src/App.jsx
import React, { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AppProvider } from './context/AppContext';
import { CartProvider } from './context/CartContext';
import useTheme from './hooks/useTheme'; // Импорт хука темы

// Pages
import HomePage from './pages/HomePage';
import CatalogPage from './pages/CatalogPage';
import ProductPage from './pages/ProductPage';
import CartPage from './pages/CartPage';
import CheckoutPage from './pages/CheckoutPage';
import OrderSuccessPage from './pages/OrderSuccessPage';

// Global CSS
import './assets/styles/global.css';

const AppContent = () => {
    // Используем хук для настройки темы Telegram
    useTheme();

    return (
        <Router>
            <div className="app-content">
                <Routes>
                    <Route path="/" element={<HomePage />} />
                    <Route path="/catalog/:categoryId" element={<CatalogPage />} />
                    <Route path="/product/:productId" element={<ProductPage />} />
                    <Route path="/cart" element={<CartPage />} />
                    <Route path="/checkout" element={<CheckoutPage />} />
                    <Route path="/order/success/:orderId" element={<OrderSuccessPage />} />
                    <Route path="*" element={<Navigate to="/" replace />} />
                </Routes>
            </div>
        </Router>
    );
};

const App = () => {
    // Модифицируем стили body для правильного скроллинга
    useEffect(() => {
        // Отключаем overflow на body, но оставляем скроллинг внутри приложения
        document.body.style.overflow = 'hidden';
        document.body.style.position = 'fixed';
        document.body.style.width = '100%';
        document.body.style.height = '100%';
        document.body.style.top = '0';
        document.body.style.left = '0';

        return () => {
            document.body.style.overflow = '';
            document.body.style.position = '';
            document.body.style.width = '';
            document.body.style.height = '';
            document.body.style.top = '';
            document.body.style.left = '';
        };
    }, []);

    return (
        <AppProvider>
            <CartProvider>
                <AppContent />
            </CartProvider>
        </AppProvider>
    );
};

export default App;
