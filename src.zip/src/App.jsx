// src/App.jsx
import React, { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, useNavigate, useLocation } from 'react-router-dom';
import { AppProvider } from './context/AppContext';
import { CartProvider } from './context/CartContext';
import useTheme from './hooks/useTheme';

// Pages
import HomePage from './pages/HomePage';
import CatalogPage from './pages/CatalogPage';
import ProductPage from './pages/ProductPage';
import CartPage from './pages/CartPage';
import CheckoutPage from './pages/CheckoutPage';
import OrderStatusPage from './pages/OrderStatusPage';
import OrderSuccessPage from './pages/OrderSuccessPage';

// Global CSS
import './assets/styles/global.css';

// Компонент для проверки состояния после возвращения в приложение
const AppRoutes = () => {
    const navigate = useNavigate();
    const location = useLocation();
    useTheme(); // Используем хук для настройки темы Telegram

    useEffect(() => {
        // Проверяем, находимся ли мы на странице checkout после возврата из платежной системы
        if (location.pathname === '/checkout') {
            // Получаем сохраненный ID заказа
            const lastOrderId = localStorage.getItem('lastOrderId');

            // Если есть ID заказа, перенаправляем на страницу статуса
            if (lastOrderId) {
                navigate(`/order/status/${lastOrderId}`);
            }
        }
    }, [location, navigate]);

    return (
        <div className="app-content">
            <Routes>
                <Route path="/" element={<HomePage />} />
                <Route path="/catalog/:categoryId" element={<CatalogPage />} />
                <Route path="/product/:productId" element={<ProductPage />} />
                <Route path="/cart" element={<CartPage />} />
                <Route path="/checkout" element={<CheckoutPage />} />
                <Route path="/order/status/:orderId" element={<OrderStatusPage />} />
                <Route path="/order/success/:orderId" element={<OrderSuccessPage />} />
                <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
        </div>
    );
};

const App = () => {
    // Модифицируем стили body для правильного скроллинга
    useEffect(() => {
        // Отключаем overflow на body, но оставляем скроллинг внутри приложения
        document.body.style.overflow = 'hidden';
        document.body.style.position = 'fixed';
        document.body.style.width = '100%';
        document.body.style.height = '100%';
        document.body.style.top = '0';
        document.body.style.left = '0';

        return () => {
            document.body.style.overflow = '';
            document.body.style.position = '';
            document.body.style.width = '';
            document.body.style.height = '';
            document.body.style.top = '';
            document.body.style.left = '';
        };
    }, []);

    return (
        <AppProvider>
            <CartProvider>
                <Router>
                    <AppRoutes />
                </Router>
            </CartProvider>
        </AppProvider>
    );
};

export default App;