// src/api/index.js
import axios from 'axios';

// Создаем инстанс axios с базовым URL и общими настройками
const api = axios.create({
    baseURL: process.env.REACT_APP_API_URL,
    headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
    },
});

// Перехватчик для добавления initData от Telegram к каждому запросу
api.interceptors.request.use((config) => {
    const telegram = window.Telegram?.WebApp;

    if (telegram) {
        // Добавляем initData для аутентификации запроса на сервере
        config.headers['X-Telegram-Init-Data'] = telegram.initData;

        // Добавляем ID пользователя, если доступен
        if (telegram.initDataUnsafe?.user?.id) {
            config.headers['X-Telegram-User-ID'] = telegram.initDataUnsafe.user.id;
        }
    }

    return config;
});

export default api;
