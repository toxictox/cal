import api from './index';

export const orderApi = {
    // Создание заказа
    createOrder: (deliveryInfo) => api.post('/orders', deliveryInfo),

    // Получение информации о заказе
    getOrder: (orderId) => api.get(`/orders/${orderId}`),

    // Инициализация платежа
    initiatePayment: (orderId, paymentMethod) =>
        api.post(`/orders/${orderId}/payments`, { payment_method: paymentMethod }),

    // Получение истории заказов пользователя
    getOrderHistory: () => api.get('/orders/history'),
};
