import api from './index';

export const cartApi = {
    // Получение корзины пользователя
    getCart: () => api.get('/cart'),

    // Добавление товара в корзину
    addToCart: (productId, quantity = 1) => api.post('/cart/items', { product_id: productId, quantity }),

    // Обновление количества товара в корзине
    updateCartItem: (cartItemId, quantity) => api.patch(`/cart/items/${cartItemId}`, { quantity }),

    // Удаление товара из корзины
    removeFromCart: (cartItemId) => api.delete(`/cart/items/${cartItemId}`),

    // Очистка всей корзины
    clearCart: () => api.delete('/cart/items'),
};
