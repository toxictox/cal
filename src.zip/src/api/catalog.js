import api from './index';

export const catalogApi = {
    // Получение всех категорий
    getCategories: () => api.get('/categories'),

    // Получение товаров по категории
    getProductsByCategory: (categoryId) => api.get(`/categories/${categoryId}/products`),

    // Получение данных конкретного товара
    getProduct: (productId) => api.get(`/products/${productId}`),

    // Поиск товаров
    searchProducts: (query) => api.get(`/products/search?q=${encodeURIComponent(query)}`),
};
