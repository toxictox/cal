import { useEffect, useState, useCallback } from 'react';

const useTelegram = () => {
    const [tg, setTg] = useState(null);
    const [user, setUser] = useState(null);
    const [isReady, setIsReady] = useState(false);

    // Инициализация Telegram Web App SDK
    useEffect(() => {
        const telegram = window.Telegram?.WebApp;

        if (telegram) {
            // Устанавливаем максимальную высоту для корректного отображения
            telegram.expand();

            // Сохраняем объект Telegram WebApp и данные пользователя
            setTg(telegram);
            setUser(telegram.initDataUnsafe?.user || {});
            setIsReady(true);

            // Сообщаем Telegram, что приложение готово к отображению
            telegram.ready();
        }
    }, []);

    // Функция для настройки основной кнопки в нижней части интерфейса
    const showMainButton = useCallback((text, onClick) => {
        if (!tg) return;

        // ВАЖНО: Сначала удаляем все существующие обработчики
        tg.MainButton.offClick();

        // Затем устанавливаем новые параметры и обработчик
        tg.MainButton.setParams({
            text,
            color: '#2cab37',
            textColor: '#ffffff',
            is_visible: true,
        });

        tg.MainButton.onClick(onClick);
        tg.MainButton.show();
    }, [tg]);

    // Функция для скрытия основной кнопки
    const hideMainButton = useCallback(() => {
        if (!tg) return;

        // ВАЖНО: Очищаем обработчики перед скрытием
        tg.MainButton.offClick();
        tg.MainButton.hide();
    }, [tg]);

    // Функция для показа всплывающего уведомления
    const showPopup = useCallback((message, callback) => {
        if (!tg) return;
        tg.showPopup({
            message,
            buttons: [{ type: 'ok' }]
        }, callback);
    }, [tg]);

    // Функция для отображения подтверждения действия
    const showConfirm = useCallback((message, callback) => {
        if (!tg) return;
        tg.showConfirm(message, callback);
    }, [tg]);

    // Настройка кнопки "Назад"
    const setupBackButton = useCallback((isVisible, onClick) => {
        if (!tg) return;

        // Сначала удаляем все обработчики
        tg.BackButton.offClick();

        if (isVisible) {
            // Затем настраиваем новое поведение
            tg.BackButton.show();
            tg.BackButton.onClick(onClick);
        } else {
            tg.BackButton.hide();
        }
    }, [tg]);

    // Функция для закрытия приложения
    const closeApp = useCallback(() => {
        if (!tg) return;
        tg.close();
    }, [tg]);

    // Функция для получения темы
    const getColorScheme = useCallback(() => {
        if (!tg) return 'light';
        return tg.colorScheme || 'light';
    }, [tg]);

    return {
        tg,
        user,
        isReady,
        showMainButton,
        hideMainButton,
        showPopup,
        showConfirm,
        setupBackButton,
        closeApp,
        getColorScheme,
    };
};

export default useTelegram;
