// src/hooks/useTheme.js
import { useEffect } from 'react';
import { useAppContext } from '../context/AppContext';

const useTheme = () => {
    const { telegram } = useAppContext();

    useEffect(() => {
        // Получаем Telegram WebApp объект из контекста
        const tg = telegram?.tg;
        if (!tg) return;

        // Определяем текущую тему Telegram
        const isDarkTheme = tg.colorScheme === 'dark';

        // Добавляем соответствующий класс к body
        if (isDarkTheme) {
            document.body.classList.add('telegram-dark-theme');
            document.body.classList.add('dark');
            document.body.classList.remove('light');
        } else {
            document.body.classList.remove('telegram-dark-theme');
            document.body.classList.add('light');
            document.body.classList.remove('dark');
        }

        // Устанавливаем CSS переменные для темы Telegram
        const root = document.documentElement;

        if (tg.themeParams) {
            // Основные цвета из Telegram WebApp
            root.style.setProperty('--tg-theme-bg-color', tg.themeParams.bg_color || '#ffffff');
            root.style.setProperty('--tg-theme-text-color', tg.themeParams.text_color || '#000000');
            root.style.setProperty('--tg-theme-hint-color', tg.themeParams.hint_color || '#999999');
            root.style.setProperty('--tg-theme-link-color', tg.themeParams.link_color || '#2481cc');
            root.style.setProperty('--tg-theme-button-color', tg.themeParams.button_color || '#2cab37');
            root.style.setProperty('--tg-theme-button-text-color', tg.themeParams.button_text_color || '#ffffff');
            root.style.setProperty('--tg-theme-secondary-bg-color', tg.themeParams.secondary_bg_color || (isDarkTheme ? '#2c2c2c' : '#f0f0f0'));

            // Заменяем ваши переменные на значения из Telegram для лучшей интеграции
            root.style.setProperty('--text-primary', tg.themeParams.text_color || (isDarkTheme ? '#ffffff' : '#000000'));
            root.style.setProperty('--text-secondary', tg.themeParams.hint_color || (isDarkTheme ? '#aaaaaa' : '#666666'));
            root.style.setProperty('--bg-gray', tg.themeParams.bg_color || (isDarkTheme ? '#212121' : '#f5f5f5'));
            root.style.setProperty('--bg-white', tg.themeParams.bg_color || (isDarkTheme ? '#1f1f1f' : '#ffffff'));
            root.style.setProperty('--bg-dark', tg.themeParams.bg_color || '#212121');
            root.style.setProperty('--bg-gray-light', tg.themeParams.secondary_bg_color || (isDarkTheme ? '#3a3a3a' : '#e9e9e9'));
        }

        // Обработчик события изменения темы Telegram
        const handleThemeChange = () => {
            // Обновляем тему при изменении
            window.location.reload();
        };

        // Если Telegram API поддерживает событие изменения темы (в будущих версиях)
        if (tg.onEvent) {
            tg.onEvent('themeChanged', handleThemeChange);

            // Очистка при размонтировании
            return () => {
                if (tg.offEvent) {
                    tg.offEvent('themeChanged', handleThemeChange);
                }
            };
        }
    }, [telegram?.tg]);
};

export default useTheme;
