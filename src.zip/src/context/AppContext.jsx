import React, { createContext, useState, useContext, useEffect } from 'react';
import useTelegram from '../hooks/useTelegram';

const AppContext = createContext();

export const useAppContext = () => useContext(AppContext);

export const AppProvider = ({ children }) => {
    const telegram = useTelegram();
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [colorScheme, setColorScheme] = useState('light');

    // Инициализация приложения
    useEffect(() => {
        if (telegram.isReady) {
            setColorScheme(telegram.getColorScheme());
            setLoading(false);
        }
    }, [telegram.isReady, telegram.getColorScheme]);

    // Обработка ошибок
    const handleError = (error) => {
        console.error('Application error:', error);
        setError(error?.message || 'Произошла ошибка');

        // Показываем сообщение об ошибке в интерфейсе Telegram
        if (telegram.showPopup) {
            telegram.showPopup(`Ошибка: ${error?.message || 'Неизвестная ошибка'}`, () => {
                setError(null);
            });
        }
    };

    // Очистка ошибки
    const clearError = () => setError(null);

    const value = {
        telegram,
        loading,
        error,
        colorScheme,
        handleError,
        clearError,
    };

    return (
        <AppContext.Provider value={value}>
            {children}
        </AppContext.Provider>
    );
};
