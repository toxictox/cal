// src/context/CartContext.js
import React, { createContext, useState, useContext, useEffect } from 'react';
import { cartApi } from '../api/cart';
import { useAppContext } from './AppContext';

const CartContext = createContext();

export const useCartContext = () => useContext(CartContext);

export const CartProvider = ({ children }) => {
    const { handleError } = useAppContext();
    const [cart, setCart] = useState({ items: [], total: 0 });
    const [loading, setLoading] = useState(false);

    // Загружаем корзину при монтировании
    useEffect(() => {
        const fetchInitialCart = async () => {
            try {
                const { data } = await cartApi.getCart();
                setCart({
                    items: data.items || [],
                    total: data.total || 0
                });
            } catch (error) {
                console.error('Ошибка при загрузке корзины:', error);
                setCart({ items: [], total: 0 });
            }
        };

        fetchInitialCart();
    }, []);

    // Загрузка корзины
    const fetchCart = async () => {
        try {
            const { data } = await cartApi.getCart();
            setCart({
                items: data.items || [],
                total: data.total || 0
            });
            return true;
        } catch (error) {
            handleError(error);
            return false;
        }
    };

    // Добавление в корзину
    const addToCart = async (productId, quantity = 1) => {
        setLoading(true);
        try {
            await cartApi.addToCart(productId, quantity);
            await fetchCart();
            return true;
        } catch (error) {
            handleError(error);
            return false;
        } finally {
            setLoading(false);
        }
    };

    // Обновление количества
    const updateQuantity = async (cartItemId, quantity) => {
        setLoading(true);
        try {
            if (quantity <= 0) {
                await cartApi.removeFromCart(cartItemId);
            } else {
                await cartApi.updateCartItem(cartItemId, quantity);
            }
            await fetchCart();
            return true;
        } catch (error) {
            handleError(error);
            return false;
        } finally {
            setLoading(false);
        }
    };

    // Удаление из корзины
    const removeFromCart = async (cartItemId) => {
        setLoading(true);
        try {
            await cartApi.removeFromCart(cartItemId);
            await fetchCart();
            return true;
        } catch (error) {
            handleError(error);
            return false;
        } finally {
            setLoading(false);
        }
    };

    // Очистка корзины
    const clearCart = async () => {
        setLoading(true);
        try {
            await cartApi.clearCart();
            setCart({ items: [], total: 0 });
            return true;
        } catch (error) {
            handleError(error);
            return false;
        } finally {
            setLoading(false);
        }
    };

    // Подсчет количества
    const itemsCount = cart.items.reduce((acc, item) => acc + item.quantity, 0);

    const value = {
        cart,
        loading,
        itemsCount,
        addToCart,
        updateQuantity,
        removeFromCart,
        clearCart,
        fetchCart,
    };

    return (
        <CartContext.Provider value={value}>
            {children}
        </CartContext.Provider>
    );
};