// src/pages/OrderSuccessPage.jsx
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { orderApi } from '../api/order';
import { useAppContext } from '../context/AppContext';
import Header from '../components/UI/Header';
import Loader from '../components/UI/Loader';
import MainButton from '../components/UI/MainButton';
import './OrderSuccessPage.css';

const OrderSuccessPage = () => {
    const { orderId } = useParams();
    const navigate = useNavigate();
    const { handleError } = useAppContext();
    const [order, setOrder] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchOrder = async () => {
            if (!orderId) {
                navigate('/');
                return;
            }

            try {
                const { data } = await orderApi.getOrder(orderId);
                setOrder(data);
            } catch (error) {
                handleError(error);
            } finally {
                setLoading(false);
            }
        };

        fetchOrder();
    }, [orderId, handleError, navigate]);

    const handleGoToCatalog = () => {
        navigate('/');
    };

    if (loading) {
        return <Loader />;
    }

    return (
        <div className="order-success-page">
            <Header title="Заказ оформлен" showCart={false} />

            <div className="success-content">
                <div className="success-icon">✅</div>

                <h1>Спасибо за заказ!</h1>

                <p className="order-number">Номер заказа: #{orderId}</p>

                {order && (
                    <div className="order-details">
                        <p>Сумма заказа: <strong>{order.total_price} TON</strong></p>
                        <p>Способ оплаты: <strong>
                            {order.payment_method === 'ton' && 'TON'}
                            {order.payment_method === 'card' && 'Банковская карта'}
                            {order.payment_method === 'cash' && 'Наличными при получении'}
                        </strong></p>

                        <p className="delivery-info">
                            Заказ будет доставлен по адресу:<br />
                            <strong>{order.delivery_info.address}</strong>
                        </p>
                    </div>
                )}

                <p className="info-message">
                    {order?.payment_method === 'cash'
                        ? 'Наш курьер свяжется с вами для уточнения деталей доставки.'
                        : 'Мы уведомим вас о статусе заказа.'}
                </p>
            </div>

            <MainButton
                text="Вернуться в каталог"
                onClick={handleGoToCatalog}
            />
        </div>
    );
};

export default OrderSuccessPage;
