// src/pages/HomePage.jsx
import React from 'react';
import CategoryList from '../components/catalog/CategoryList';
import Header from '../components/UI/Header';
import './HomePage.css';

const HomePage = () => {
    return (
        <div className="home-page">
            <Header title="Каталог товаров" />
            <CategoryList />
        </div>
    );
};

export default HomePage;
