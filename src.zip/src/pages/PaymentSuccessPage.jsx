// src/pages/PaymentSuccessPage.jsx
import React, { useEffect, useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAppContext } from '../context/AppContext';
import { orderApi } from '../api/order';
import Header from '../components/UI/Header';
import Loader from '../components/UI/Loader';
import MainButton from '../components/UI/MainButton';
import './PaymentSuccessPage.css';

const PaymentSuccessPage = () => {
    const [order, setOrder] = useState(null);
    const [loading, setLoading] = useState(true);
    const { handleError, telegram } = useAppContext();
    const navigate = useNavigate();
    const location = useLocation();

    useEffect(() => {
        const fetchOrderDetails = async () => {
            setLoading(true);
            try {
                // Получаем orderId из query params
                const params = new URLSearchParams(location.search);
                const orderId = params.get('order_id');

                if (!orderId) {
                    throw new Error('Идентификатор заказа не найден');
                }

                // Получаем детали заказа
                const { data } = await orderApi.getOrder(orderId);
                setOrder(data);

                // Показываем уведомление
                telegram?.showPopup('Оплата прошла успешно!');
            } catch (error) {
                handleError(error);
            } finally {
                setLoading(false);
            }
        };

        fetchOrderDetails();
    }, [location, handleError, telegram]);

    const handleContinueShopping = () => {
        navigate('/');
    };

    if (loading) {
        return <Loader text="Загрузка информации о заказе..." />;
    }

    return (
        <div className="payment-success-page">
            <Header title="Оплата выполнена" />

            <div className="success-container">
                <div className="success-icon">✓</div>
                <h2>Заказ успешно оплачен!</h2>

                {order && (
                    <div className="order-details">
                        <p className="order-number">Заказ #{order.id}</p>
                        <p className="order-date">от {new Date(order.created_at).toLocaleDateString()}</p>

                        <div className="order-summary">
                            <h3>Информация о заказе:</h3>
                            <p>Статус: <strong>{order.status}</strong></p>
                            <p>Сумма: <strong>{order.total} TON</strong></p>
                            <p>Способ оплаты: <strong>{order.payment_method}</strong></p>
                        </div>

                        <div className="delivery-info">
                            <h3>Информация о доставке:</h3>
                            <p><strong>{order.name}</strong></p>
                            <p>{order.phone}</p>
                            <p>{order.address}</p>
                            {order.comment && <p>Комментарий: {order.comment}</p>}
                        </div>
                    </div>
                )}

                <p className="thank-you-message">
                    Спасибо за ваш заказ! Мы уведомим вас о статусе доставки.
                </p>

                <MainButton
                    text="Продолжить покупки"
                    onClick={handleContinueShopping}
                />
            </div>
        </div>
    );
};

export default PaymentSuccessPage;
