// src/pages/CheckoutPage.jsx
import React from 'react';
import CheckoutForm from '../components/checkout/CheckoutForm';
import './CheckoutPage.css';

const CheckoutPage = () => {
    return (
        <div className="checkout-page-container">
            <CheckoutForm />
        </div>
    );
};

export default CheckoutPage;
