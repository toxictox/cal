// src/pages/CatalogPage.jsx
import React from 'react';
import { useParams } from 'react-router-dom';
import ProductList from '../components/catalog/ProductList';
import Header from '../components/UI/Header';
import BackButton from '../components/UI/BackButton';
import './CatalogPage.css';

const CatalogPage = () => {
    const { categoryId } = useParams();

    return (
        <div className="catalog-page">
            <Header title="Товары" showBack={true} />
            <BackButton to="/" />
            <ProductList categoryId={categoryId} />
        </div>
    );
};

export default CatalogPage;
