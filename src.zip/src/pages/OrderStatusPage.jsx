// src/pages/OrderStatusPage.jsx
import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { orderApi } from '../api/order';
import { useAppContext } from '../context/AppContext';
import Header from '../components/UI/Header';
import Loader from '../components/UI/Loader';
import MainButton from '../components/UI/MainButton';
import './OrderStatusPage.css';

const OrderStatusPage = () => {
    const { orderId } = useParams();
    const [order, setOrder] = useState(null);
    const [loading, setLoading] = useState(true);
    const { handleError, telegram } = useAppContext();

    // Функция для проверки статуса заказа
    const checkOrderStatus = async () => {
        try {
            const { data } = await orderApi.getOrder(orderId);
            setOrder(data);

            // Если статус изменился на "оплачен", показываем уведомление
            if (data.status === 'paid' && order && order.status !== 'paid') {
                telegram?.showPopup('Платеж успешно обработан!');
            }

            return data;
        } catch (error) {
            handleError(error);
            return null;
        }
    };

    // При монтировании компонента загружаем данные о заказе
    useEffect(() => {
        const fetchOrder = async () => {
            setLoading(true);
            await checkOrderStatus();
            setLoading(false);
        };

        fetchOrder();
    }, [orderId]);

    // Периодически проверяем статус заказа
    useEffect(() => {
        let intervalId;

        if (order && order.status !== 'paid' && order.status !== 'cancelled') {
            intervalId = setInterval(async () => {
                const updatedOrder = await checkOrderStatus();

                // Прекращаем опрос, если заказ оплачен или отменен
                if (updatedOrder && (updatedOrder.status === 'paid' || updatedOrder.status === 'cancelled')) {
                    clearInterval(intervalId);
                }
            }, 5000); // Проверяем каждые 5 секунд
        }

        return () => {
            if (intervalId) clearInterval(intervalId);
        };
    }, [order]);

    // Кнопка для проверки статуса вручную
    const handleCheckStatus = async () => {
        setLoading(true);
        await checkOrderStatus();
        setLoading(false);
    };

    // Кнопка для возврата на главную
    const handleReturnHome = () => {
        window.location.href = '/';
    };

    if (loading && !order) {
        return <Loader text="Загрузка информации о заказе..." />;
    }

    if (!order) {
        return (
            <div className="order-status-page">
                <Header title="Информация о заказе" />
                <div className="error-container">
                    <h2>Заказ не найден</h2>
                    <p>К сожалению, информация о заказе не найдена.</p>
                    <MainButton text="Вернуться на главную" onClick={handleReturnHome} />
                </div>
            </div>
        );
    }

    // Отображение в зависимости от статуса заказа
    return (
        <div className="order-status-page">
            <Header title="Информация о заказе" />

            <div className="order-status-container">
                <h2>Заказ #{order.id}</h2>
                <p className="order-date">от {new Date(order.created_at).toLocaleDateString()}</p>

                <div className={`status-badge ${order.status}`}>
                    {order.status === 'pending' && 'Ожидает оплаты'}
                    {order.status === 'processing' && 'Обработка платежа'}
                    {order.status === 'paid' && 'Оплачен'}
                    {order.status === 'cancelled' && 'Отменен'}
                    {order.status === 'completed' && 'Выполнен'}
                </div>

                <div className="order-summary">
                    <h3>Сумма заказа: {order.total} TON</h3>
                    <p>Способ оплаты: {order.payment_method}</p>
                </div>

                <div className="customer-info">
                    <h3>Информация о получателе:</h3>
                    <p>{order.name}</p>
                    <p>{order.phone}</p>
                    <p>{order.address}</p>
                </div>

                {(order.status === 'pending' || order.status === 'processing') && (
                    <div className="payment-processing">
                        <p>Мы обрабатываем ваш платеж.</p>
                        <p>Это может занять некоторое время.</p>
                        <div className="refresh-button-container">
                            <button
                                onClick={handleCheckStatus}
                                disabled={loading}
                                className="refresh-button"
                            >
                                {loading ? 'Проверка...' : 'Обновить статус'}
                            </button>
                        </div>
                    </div>
                )}

                {order.status === 'paid' && (
                    <div className="payment-success">
                        <div className="success-icon">✓</div>
                        <p>Спасибо за ваш заказ!</p>
                        <p>Мы свяжемся с вами для уточнения деталей доставки.</p>
                    </div>
                )}

                {order.status === 'cancelled' && (
                    <div className="payment-failed">
                        <p>К сожалению, заказ был отменен.</p>
                        <p>Если вы уже произвели оплату, свяжитесь с нами для уточнения деталей.</p>
                    </div>
                )}

                <MainButton
                    text="Вернуться в магазин"
                    onClick={handleReturnHome}
                />
            </div>
        </div>
    );
};

export default OrderStatusPage;
