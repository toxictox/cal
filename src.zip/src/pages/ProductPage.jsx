// src/pages/ProductPage.jsx
import React from 'react';
import { useParams } from 'react-router-dom';
import ProductDetail from '../components/catalog/ProductDetail';
import Header from '../components/UI/Header';
import './ProductPage.css';

const ProductPage = () => {
    const { productId } = useParams();

    return (
        <div className="product-page">
            <Header title="Товар" showBack={true} />
            <ProductDetail productId={productId} />
        </div>
    );
};

export default ProductPage;
