// src/components/Cart/CartPage.jsx
import React from 'react';
import { useCartContext } from '../context/CartContext';
import CartItem from '../components/cart/CartItem';
import CartSummary from '../components/cart/CartSummary';
import Header from '../components/UI/Header';
import Loader from '../components/UI/Loader';
import BackButton from '../components/UI/BackButton';
import './CartPage.css';

const CartPage = () => {
    const { cart, loading } = useCartContext();

    if (loading) {
        return <Loader />;
    }

    return (
        <div className="cart-page">
            <Header title="Корзина" showCart={false} showBack={true} />
            <BackButton to="/" />

            <div className="cart-container">
                {cart.items.length === 0 ? (
                    <div className="empty-cart">
                        <p>Ваша корзина пуста</p>
                        <button
                            className="continue-shopping-btn"
                            onClick={() => window.history.back()}
                        >
                            Перейти к покупкам
                        </button>
                    </div>
                ) : (
                    <>
                        <div className="cart-items-list">
                            {cart.items.map(item => (
                                <CartItem key={item.id} item={item} />
                            ))}
                        </div>

                        <CartSummary />
                    </>
                )}
            </div>
        </div>
    );
};

export default CartPage;
