import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';

// Настройка цветовой схемы на основе данных Telegram WebApp
const setColorScheme = () => {
    const telegram = window.Telegram?.WebApp;

    if (telegram) {
        document.documentElement.dataset.theme = telegram.colorScheme || 'light';
        document.body.className = telegram.colorScheme || 'light';
    }
};

// Инициализация цветовой схемы
setColorScheme();

// Создание корня приложения
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
    <React.StrictMode>
        <App />
    </React.StrictMode>
);

// Обработчик изменения цветовой схемы Telegram
window.Telegram?.WebApp?.onEvent('themeChanged', setColorScheme);
