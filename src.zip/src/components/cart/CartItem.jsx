// src/components/Cart/CartItem.jsx
import React from 'react';
import { useCartContext } from '../../context/CartContext';
import './CartItem.css';

const CartItem = ({ item }) => {
    const { updateQuantity, removeFromCart } = useCartContext();

    const handleIncrement = () => {
        updateQuantity(item.id, item.quantity + 1);
    };

    const handleDecrement = () => {
        if (item.quantity > 1) {
            updateQuantity(item.id, item.quantity - 1);
        } else {
            handleRemove();
        }
    };

    const handleRemove = () => {
        removeFromCart(item.id);
    };

    return (
        <div className="cart-item">
            <div className="cart-item-image">
                {item.product.image_filename ? (
                    <img
                        src={`${process.env.REACT_APP_API_URL}/uploads/${item.product.image_filename}`}
                        alt={item.product.name}
                    />
                ) : (
                    <div className="cart-no-image">Нет фото</div>
                )}
            </div>

            <div className="cart-item-details">
                <h3 className="cart-item-name">{item.product.name}</h3>
                <p className="cart-item-price">{item.product.price} TON</p>
            </div>

            <div className="cart-item-actions">
                <div className="cart-quantity-controls">
                    <button
                        className="cart-quantity-btn"
                        onClick={handleDecrement}
                        aria-label="Уменьшить количество"
                    >
                        -
                    </button>
                    <span className="cart-quantity">{item.quantity}</span>
                    <button
                        className="cart-quantity-btn"
                        onClick={handleIncrement}
                        aria-label="Увеличить количество"
                    >
                        +
                    </button>
                </div>

                <button
                    className="cart-remove-btn"
                    onClick={handleRemove}
                    aria-label="Удалить из корзины"
                >
                    ×
                </button>
            </div>

            <div className="cart-item-total">
                {(item.product.price * item.quantity).toFixed(2)} TON
            </div>
        </div>
    );
};

export default CartItem;
