// src/components/Cart/CartSummary.jsx
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useCartContext } from '../../context/CartContext';
import { useAppContext } from '../../context/AppContext';
import MainButton from '../UI/MainButton';
import './CartSummary.css';

const CartSummary = () => {
    const { cart, clearCart, loading } = useCartContext();
    const { telegram } = useAppContext();
    const navigate = useNavigate();
    const [isClearing, setIsClearing] = useState(false);
    const [isCheckingOut, setIsCheckingOut] = useState(false);

    const handleCheckout = async () => {
        if (isCheckingOut || loading) return;

        setIsCheckingOut(true);

        // Добавляем задержку, чтобы предотвратить непреднамеренные переходы
        setTimeout(() => {
            navigate('/checkout');
            setIsCheckingOut(false);
        }, 300);
    };

    const handleClearCart = async () => {
        if (isClearing || loading) return;

        // Показываем подтверждение перед очисткой
        if (telegram && telegram.showConfirm) {
            telegram.showConfirm("Вы уверены, что хотите очистить корзину?", async (confirmed) => {
                if (confirmed) {
                    setIsClearing(true);
                    await clearCart();
                    setIsClearing(false);
                }
            });
        } else {
            // Если Telegram API недоступно, используем стандартное подтверждение
            if (window.confirm("Вы уверены, что хотите очистить корзину?")) {
                setIsClearing(true);
                await clearCart();
                setIsClearing(false);
            }
        }
    };

    // Получаем общее количество товаров
    const totalItems = cart.items.reduce((acc, item) => acc + item.quantity, 0);

    // Форматируем общую стоимость
    const formattedTotal = typeof cart.total === 'number'
        ? cart.total.toFixed(2)
        : '0.00';

    return (
        <div className="cart-summary">
            <div className="cart-summary-details">
                <div className="cart-summary-row">
                    <span>Количество товаров:</span>
                    <span>{totalItems}</span>
                </div>

                <div className="cart-summary-row cart-summary-total">
                    <span>Итого:</span>
                    <span>{formattedTotal} TON</span>
                </div>
            </div>

            <div className="cart-summary-actions">
                <button
                    className="cart-clear-btn"
                    onClick={handleClearCart}
                    disabled={isClearing || loading || cart.items.length === 0}
                >
                    {isClearing ? 'Очистка...' : 'Очистить корзину'}
                </button>
            </div>

            <MainButton
                text={isCheckingOut
                    ? 'Переход к оформлению...'
                    : `Оформить заказ на ${formattedTotal} TON`}
                onClick={handleCheckout}
                disabled={isCheckingOut || loading || cart.items.length === 0}
            />
        </div>
    );
};

export default CartSummary;
