// src/components/Checkout/CheckoutForm.jsx
import React, { useState, useCallback, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { orderApi } from '../../api/order';
import { useCartContext } from '../../context/CartContext';
import { useAppContext } from '../../context/AppContext';
import DeliveryInfo from './DeliveryInfo';
import PaymentMethod from './PaymentMethod';
import OrderSummary from './OrderSummary';
import Header from '../UI/Header';
import BackButton from '../UI/BackButton';
import MainButton from '../UI/MainButton';
import Loader from '../UI/Loader';
import './CheckoutForm.css';

const CheckoutForm = () => {
    const navigate = useNavigate();
    const { fetchCart } = useCartContext();
    const { handleError, telegram } = useAppContext();

    const [deliveryInfo, setDeliveryInfo] = useState({
        name: '',
        phone: '',
        address: '',
        comment: ''
    });

    const [paymentMethod, setPaymentMethod] = useState('ton');
    const [loading, setLoading] = useState(false);
    const [isSubmitting, setIsSubmitting] = useState(false);

    // Используем useRef для отслеживания состояния отправки без перерендера
    const submittingRef = useRef(false);

    const deliveryInfoRef = useRef({
        name: '',
        phone: '',
        address: '',
        comment: ''
    });

    const handleDeliveryInfoChange = (info) => {
        // Обновляем и state, и ref
        setDeliveryInfo(info);
        deliveryInfoRef.current = info;
    };

    const handlePaymentMethodChange = (method) => {
        setPaymentMethod(method);
    };

    // Используем useCallback с минимальным набором зависимостей
    const handleSubmit = useCallback(async () => {
        // Используем ref для проверки состояния отправки
        if (submittingRef.current || loading) {
            return;
        }

        // Базовая валидация
        const currentInfo = deliveryInfoRef.current;
        if (!currentInfo.name || !currentInfo.phone || !currentInfo.address) {
            telegram.showPopup('Пожалуйста, заполните все обязательные поля');
            return;
        }

        // Устанавливаем флаги состояния отправки
        submittingRef.current = true;
        setIsSubmitting(true);
        setLoading(true);

        try {
            // Создаем заказ
            const { data } = await orderApi.createOrder({
                ...deliveryInfo,
                payment_method: paymentMethod
            });

            // Обрабатываем оплату в зависимости от выбранного метода
            if (paymentMethod === 'cash') {
                // Для наличных просто подтверждаем заказ
                navigate(`/order/success/${data.id}`);
            } else {
                // Для онлайн-оплаты инициируем платеж
                const paymentResponse = await orderApi.initiatePayment(
                    data.id,
                    paymentMethod
                );

                // Перенаправляем на страницу оплаты или обрабатываем платеж через Telegram
                if (paymentMethod === 'ton') {
                    // Для TON открываем внешнюю ссылку
                    telegram.tg.openLink(paymentResponse.data.payment_url);
                } else if (paymentMethod === 'card') {
                    // Для карты открываем страницу платежного шлюза
                    window.location.href = paymentResponse.data.payment_url;
                }
            }

            // Обновляем корзину (очищаем после успешного заказа)
            await fetchCart();

        } catch (error) {
            handleError(error);
        } finally {
            setLoading(false);
            setIsSubmitting(false);
            submittingRef.current = false;
        }
    }, [
        // Минимальный набор зависимостей - только функции и объекты,
        // которые не меняются при рендеринге компонента
        navigate,
        fetchCart,
        handleError,
        telegram
    ]);

    if (loading) {
        return <Loader text="Оформление заказа..." />;
    }

    return (
        <div className="checkout-page">
            <Header title="Оформление заказа" showCart={false} showBack={true} />
            <BackButton to="/cart" />

            <div className="checkout-form">
                <DeliveryInfo
                    onChange={handleDeliveryInfoChange}
                    initialValues={deliveryInfo}
                />

                <PaymentMethod
                    selected={paymentMethod}
                    onChange={handlePaymentMethodChange}
                />

                <OrderSummary />

                <MainButton
                    text="Подтвердить заказ"
                    onClick={handleSubmit}
                    disabled={isSubmitting}
                />
            </div>
        </div>
    );
};

export default CheckoutForm;
