// src/components/Checkout/PaymentMethod.jsx
import React from 'react';
import './PaymentMethod.css';

const PaymentMethod = ({ selected, onChange }) => {
    const handlePaymentChange = (method) => {
        onChange(method);
    };

    return (
        <div className="payment-method">
            <h2>Способ оплаты</h2>

            <div className="payment-options">
                <div
                    className={`payment-option ${selected === 'ton' ? 'selected' : ''}`}
                    onClick={() => handlePaymentChange('ton')}
                >
                    <div className="payment-icon">💳</div>
                    <div className="payment-details">
                        <h3>TON</h3>
                        <p>Оплата криптовалютой TON</p>
                    </div>
                    <div className="payment-radio">
                        <input
                            type="radio"
                            checked={selected === 'ton'}
                            onChange={() => {}}
                        />
                    </div>
                </div>

                <div
                    className={`payment-option ${selected === 'card' ? 'selected' : ''}`}
                    onClick={() => handlePaymentChange('card')}
                >
                    <div className="payment-icon">💳</div>
                    <div className="payment-details">
                        <h3>Банковская карта</h3>
                        <p>Оплата через Newpay.kz</p>
                    </div>
                    <div className="payment-radio">
                        <input
                            type="radio"
                            checked={selected === 'card'}
                            onChange={() => {}}
                        />
                    </div>
                </div>

                <div
                    className={`payment-option ${selected === 'cash' ? 'selected' : ''}`}
                    onClick={() => handlePaymentChange('cash')}
                >
                    <div className="payment-icon">💵</div>
                    <div className="payment-details">
                        <h3>Наличными при получении</h3>
                        <p>Оплата курьеру при доставке</p>
                    </div>
                    <div className="payment-radio">
                        <input
                            type="radio"
                            checked={selected === 'cash'}
                            onChange={() => {}}
                        />
                    </div>
                </div>
            </div>
        </div>
    );
};

export default PaymentMethod;
