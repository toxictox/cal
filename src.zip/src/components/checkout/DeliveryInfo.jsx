// src/components/Checkout/DeliveryInfo.jsx
import React, { useState } from 'react';
import { useAppContext } from '../../context/AppContext';
import './DeliveryInfo.css';

const DeliveryInfo = ({ onChange, initialValues = {} }) => {
    const { user } = useAppContext().telegram;

    // Используем данные пользователя из Telegram как значения по умолчанию
    const [form, setForm] = useState({
        name: initialValues.name || user?.first_name || '',
        phone: initialValues.phone || user?.phone_number || '',
        address: initialValues.address || '',
        comment: initialValues.comment || ''
    });

    const handleChange = (e) => {
        const { name, value } = e.target;
        setForm(prev => {
            const newForm = {
                ...prev,
                [name]: value
            };

            // Вызываем callback с новыми данными
            if (onChange) onChange(newForm);

            return newForm;
        });
    };

    return (
        <div className="delivery-info">
            <h2>Информация для доставки</h2>

            <div className="form-group">
                <label htmlFor="name">Имя</label>
                <input
                    type="text"
                    id="name"
                    name="name"
                    value={form.name}
                    onChange={handleChange}
                    placeholder="Ваше имя"
                    required
                />
            </div>

            <div className="form-group">
                <label htmlFor="phone">Телефон</label>
                <input
                    type="tel"
                    id="phone"
                    name="phone"
                    value={form.phone}
                    onChange={handleChange}
                    placeholder="Ваш номер телефона"
                    required
                />
            </div>

            <div className="form-group">
                <label htmlFor="address">Адрес доставки</label>
                <textarea
                    id="address"
                    name="address"
                    value={form.address}
                    onChange={handleChange}
                    placeholder="Полный адрес доставки"
                    rows="3"
                    required
                ></textarea>
            </div>

            <div className="form-group">
                <label htmlFor="comment">Комментарий (необязательно)</label>
                <textarea
                    id="comment"
                    name="comment"
                    value={form.comment}
                    onChange={handleChange}
                    placeholder="Дополнительная информация для доставки"
                    rows="2"
                ></textarea>
            </div>
        </div>
    );
};

export default DeliveryInfo;
