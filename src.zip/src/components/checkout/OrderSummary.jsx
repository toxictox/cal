// src/components/Checkout/OrderSummary.jsx
import React from 'react';
import { useCartContext } from '../../context/CartContext';
import './OrderSummary.css';

const OrderSummary = () => {
    const { cart } = useCartContext();

    return (
        <div className="order-summary">
            <h2>Ваш заказ</h2>

            <div className="order-items">
                {cart.items.map(item => (
                    <div key={item.id} className="order-item">
                        <div className="order-item-info">
                            <span className="order-item-name">{item.product.name}</span>
                            <span className="order-item-quantity">x{item.quantity}</span>
                        </div>
                        <span className="order-item-price">
              {(item.product.price * item.quantity).toFixed(2)} TON
            </span>
                    </div>
                ))}
            </div>

            <div className="order-total">
                <span>Итого:</span>
                <span>{cart.total.toFixed(2)} TON</span>
            </div>
        </div>
    );
};

export default OrderSummary;
