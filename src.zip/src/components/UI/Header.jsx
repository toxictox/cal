// src/components/UI/Header.jsx
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useCartContext } from '../../context/CartContext';
import { useAppContext } from '../../context/AppContext';
import './Header.css';

const Header = ({ title, showCart = true, showBack = false }) => {
    const navigate = useNavigate();
    const { itemsCount } = useCartContext();
    const { colorScheme } = useAppContext();

    const goToCart = () => {
        navigate('/cart');
    };

    const goBack = () => {
        navigate(-1);
    };

    return (
        <header className={`header ${colorScheme}`}>
            <div className="header-content">
                {showBack && (
                    <button className="back-button" onClick={goBack}>
                        ←
                    </button>
                )}

                <h1 className="header-title">{title}</h1>

                {showCart && (
                    <button className="cart-button" onClick={goToCart}>
                        🛒
                        {itemsCount > 0 && <span className="cart-badge">{itemsCount}</span>}
                    </button>
                )}
            </div>
        </header>
    );
};

export default Header;
