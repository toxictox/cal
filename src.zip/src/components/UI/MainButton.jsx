// src/components/UI/MainButton.jsx
import React, { useEffect } from 'react';
import useTelegram from '../../hooks/useTelegram';

const MainButton = ({ text, onClick, disabled = false }) => {
    const { showMainButton, hideMainButton } = useTelegram();

    useEffect(() => {
        if (!disabled) {
            showMainButton(text, onClick);
        } else {
            hideMainButton();
        }

        // Очистка при размонтировании компонента
        return () => {
            hideMainButton();
        };
    }, [text, onClick, disabled, showMainButton, hideMainButton]);

    // Этот компонент не рендерит ничего видимого,
    // он только настраивает основную кнопку в Telegram
    return null;
};

export default MainButton;
