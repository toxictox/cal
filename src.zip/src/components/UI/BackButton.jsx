// src/components/UI/BackButton.jsx
import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import useTelegram  from '../../hooks/useTelegram';

const BackButton = ({ to }) => {
    const navigate = useNavigate();
    const { setupBackButton } = useTelegram();

    useEffect(() => {
        const handleBack = () => {
            if (to) {
                navigate(to);
            } else {
                navigate(-1);
            }
        };

        setupBackButton(true, handleBack);

        return () => {
            setupBackButton(false);
        };
    }, [setupBackButton, navigate, to]);

    // Этот компонент не рендерит ничего видимого,
    // он только настраивает кнопку "Назад" в Telegram
    return null;
};

export default BackButton;
