// src/components/Catalog/ProductDetail.jsx
import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { catalogApi } from '../../api/catalog';
import { useCartContext } from '../../context/CartContext';
import { useAppContext } from '../../context/AppContext';
import Loader from '../UI/Loader';
import BackButton from '../UI/BackButton';
import MainButton from '../UI/MainButton';
import './ProductDetail.css';

const ProductDetail = () => {
    const { productId } = useParams();
    const [product, setProduct] = useState(null);
    const [quantity, setQuantity] = useState(1);
    const [loading, setLoading] = useState(true);
    const [addingToCart, setAddingToCart] = useState(false);
    const { addToCart } = useCartContext();
    const { handleError, telegram } = useAppContext();

    useEffect(() => {
        const fetchProduct = async () => {
            setLoading(true);
            try {
                const { data } = await catalogApi.getProduct(productId);
                setProduct(data);
            } catch (error) {
                handleError(error);
            } finally {
                setLoading(false);
            }
        };

        fetchProduct();
    }, [productId, handleError]);

    // src/components/Catalog/ProductDetail.jsx
    const handleAddToCart = () => {
        // Предотвращаем повторные нажатия
        if (addingToCart) return;

        setAddingToCart(true);

        addToCart(product.id, quantity)
            .then(success => {
                if (success) {
                    // Используем строку вместо объекта для popup
                    telegram?.showPopup(`Товар "${product.name}" добавлен в корзину`);
                }
            })
            .catch(error => {
                handleError(error);
            })
            .finally(() => {
                // Добавляем задержку перед сбросом флага
                setTimeout(() => {
                    setAddingToCart(false);
                }, 1000);
            });
    };

    const incrementQuantity = () => {
        setQuantity(prev => prev + 1);
    };

    const decrementQuantity = () => {
        if (quantity > 1) {
            setQuantity(prev => prev - 1);
        }
    };

    if (loading) {
        return <Loader />;
    }

    if (!product) {
        return <div className="error-message">Товар не найден</div>;
    }

    return (
        <div className="product-detail-container">
            <BackButton />

            <div className="product-image-wrapper">
                {product.image_filename ? (
                    <img
                        src={`${process.env.REACT_APP_API_URL}/uploads/${product.image_filename}`}
                        alt={product.name}
                        className="product-detail-image"
                    />
                ) : (
                    <div className="product-no-image-large">Нет фото</div>
                )}
            </div>

            <div className="product-detail-info">
                <h1 className="product-detail-name">{product.name}</h1>
                <p className="product-detail-price">{product.price} TON</p>

                {product.description && (
                    <div className="product-detail-description">
                        <h3>Описание</h3>
                        <p>{product.description}</p>
                    </div>
                )}

                {product.in_stock ? (
                    <div className="in-stock-badge">В наличии</div>
                ) : (
                    <div className="out-of-stock-badge-large">Нет в наличии</div>
                )}

                {product.in_stock && (
                    <div className="product-quantity-selector">
                        <button
                            className="quantity-button"
                            onClick={decrementQuantity}
                            disabled={quantity <= 1 || addingToCart}
                        >
                            -
                        </button>
                        <span className="quantity-display">{quantity}</span>
                        <button
                            className="quantity-button"
                            onClick={incrementQuantity}
                            disabled={addingToCart}
                        >
                            +
                        </button>
                    </div>
                )}
            </div>

            {product.in_stock && (
                <button
                    className="regular-button"
                    onClick={handleAddToCart}
                    disabled={addingToCart}
                    style={{
                        padding: '12px 20px',
                        borderRadius: '8px',
                        backgroundColor: '#2cab37',
                        color: 'white',
                        border: 'none',
                        fontSize: '16px',
                        fontWeight: 'bold',
                        width: '100%',
                        marginTop: '16px',
                        cursor: addingToCart ? 'not-allowed' : 'pointer',
                        opacity: addingToCart ? 0.7 : 1
                    }}
                >
                    {addingToCart
                        ? "Добавление..."
                        : `Добавить в корзину за ${product.price * quantity} TON`}
                </button>
            )}
        </div>
    );
};

export default ProductDetail;
