// src/components/Catalog/ProductList.jsx
import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { catalogApi } from '../../api/catalog';
import { useAppContext } from '../../context/AppContext';
import ProductCard from './ProductCard';
import Loader from '../UI/Loader';
import './ProductList.css';

const ProductList = () => {
    const { categoryId } = useParams();
    const [products, setProducts] = useState([]);
    const [loading, setLoading] = useState(true);
    const [category, setCategory] = useState(null);
    const { handleError } = useAppContext();

    useEffect(() => {
        const fetchProducts = async () => {
            setLoading(true);
            try {
                const { data } = await catalogApi.getProductsByCategory(categoryId);
                setProducts(data.products || []);
                setCategory(data.category || null);
            } catch (error) {
                handleError(error);
            } finally {
                setLoading(false);
            }
        };

        fetchProducts();
    }, [categoryId, handleError]);

    if (loading) {
        return <Loader />;
    }

    return (
        <div className="product-list-container">
            <h1 className="category-title">{category?.name || 'Товары'}</h1>

            {products.length === 0 ? (
                <div className="no-products">
                    <p>В этой категории пока нет товаров</p>
                </div>
            ) : (
                <div className="product-grid">
                    {products.map(product => (
                        <ProductCard key={product.id} product={product} />
                    ))}
                </div>
            )}
        </div>
    );
};

export default ProductList;
