// src/components/Catalog/CategoryList.jsx
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAppContext } from '../../context/AppContext';
import './CategoryList.css';
import {catalogApi} from "../../api/catalog";

const CategoryList = () => {
    const navigate = useNavigate();
    const { handleError } = useAppContext();
    const [categories, setCategories] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchCategories = async () => {
            setLoading(true);
            try {
                const response = await catalogApi.getCategories();

                // Отладочный вывод, чтобы увидеть структуру ответа
                console.log('API response:', response);

                // Правильно обрабатываем ответ, в зависимости от его структуры
                let categoriesData = [];

                if (response && response.data) {
                    if (Array.isArray(response.data)) {
                        categoriesData = response.data;
                    } else if (response.data.data && Array.isArray(response.data.data)) {
                        // Если API возвращает {data: [...]}
                        categoriesData = response.data.data;
                    } else if (typeof response.data === 'object') {
                        // Если API возвращает объект вместо массива, пробуем преобразовать
                        categoriesData = Object.values(response.data).filter(item =>
                            item && typeof item === 'object' && item.id && item.name
                        );
                    }
                }

                console.log('Processed categories:', categoriesData);
                setCategories(categoriesData || []);
            } catch (error) {
                console.error('Error fetching categories:', error);
                handleError(error);
                setCategories([]); // Установка пустого массива в случае ошибки
            } finally {
                setLoading(false);
            }
        };

        fetchCategories();
    }, [handleError]);

    const handleCategoryClick = (categoryId) => {
        navigate(`/catalog/${categoryId}`);
    };

    if (loading) {
        return (
            <div className="category-list">
                <h2 className="category-list-title">Категории</h2>
                <div className="loading-indicator">Загрузка категорий...</div>
            </div>
        );
    }

    // Дополнительная проверка перед маппингом
    if (!Array.isArray(categories) || categories.length === 0) {
        return (
            <div className="category-list">
                <h2 className="category-list-title">Категории</h2>
                <div className="empty-message">Категории не найдены</div>
            </div>
        );
    }

    return (
        <div className="category-list">
            <h2 className="category-list-title">Категории</h2>
            {categories.map((category) => (
                <div
                    key={category.id || `cat-${Math.random()}`}
                    className="category-item"
                    onClick={() => handleCategoryClick(category.id)}
                >
                    <span className="category-name">{category.name || 'Категория'}</span>
                    <span className="category-arrow">→</span>
                </div>
            ))}
        </div>
    );
};

export default CategoryList;
