// src/components/Catalog/ProductCard.jsx
import React from 'react';
import { Link } from 'react-router-dom';
import { useCartContext } from '../../context/CartContext';
import './ProductCard.css';

const ProductCard = ({ product }) => {
    const { addToCart } = useCartContext();

    const handleAddToCart = (e) => {
        e.preventDefault();
        e.stopPropagation();
        addToCart(product.id, 1);
    };

    return (
        <Link to={`/product/${product.id}`} className="product-card">
            <div className="product-image-container">
                {product.image_filename ? (
                    <img
                        src={`${process.env.REACT_APP_IMAGES_URL}/${product.image_filename}`}
                        alt={product.name}
                        className="product-image"
                    />
                ) : (
                    <div className="product-no-image">Нет фото</div>
                )}

                {!product.in_stock && (
                    <div className="out-of-stock-badge">Нет в наличии</div>
                )}
            </div>

            <div className="product-info">
                <h3 className="product-name">{product.name}</h3>
                <p className="product-price">{product.price} TON</p>
            </div>

            {product.in_stock && (
                <button
                    className="add-to-cart-button"
                    onClick={handleAddToCart}
                    aria-label="Добавить в корзину"
                >
                    +
                </button>
            )}
        </Link>
    );
};

export default ProductCard;
